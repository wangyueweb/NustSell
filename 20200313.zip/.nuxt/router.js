import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _7ba9d42a = () => interopDefault(import('..\\pages\\categorylist.vue' /* webpackChunkName: "pages_categorylist" */))
const _0b63f4c8 = () => interopDefault(import('..\\pages\\goodsDetail.vue' /* webpackChunkName: "pages_goodsDetail" */))
const _2409cf72 = () => interopDefault(import('..\\pages\\help\\index.vue' /* webpackChunkName: "pages_help_index" */))
const _41370112 = () => interopDefault(import('..\\pages\\myCenter\\index.vue' /* webpackChunkName: "pages_myCenter_index" */))
const _1c079a26 = () => interopDefault(import('..\\pages\\myCenter\\account.vue' /* webpackChunkName: "pages_myCenter_account" */))
const _760ce339 = () => interopDefault(import('..\\pages\\myCenter\\addressManage.vue' /* webpackChunkName: "pages_myCenter_addressManage" */))
const _17f5f1b8 = () => interopDefault(import('..\\pages\\myCenter\\assetsManage.vue' /* webpackChunkName: "pages_myCenter_assetsManage" */))
const _2cd2436a = () => interopDefault(import('..\\pages\\myCenter\\collect.vue' /* webpackChunkName: "pages_myCenter_collect" */))
const _5b4e208c = () => interopDefault(import('..\\pages\\myCenter\\notice\\index.vue' /* webpackChunkName: "pages_myCenter_notice_index" */))
const _12275198 = () => interopDefault(import('..\\pages\\myCenter\\order\\index.vue' /* webpackChunkName: "pages_myCenter_order_index" */))
const _0db8e006 = () => interopDefault(import('..\\pages\\myCenter\\safe.vue' /* webpackChunkName: "pages_myCenter_safe" */))
const _6802be6a = () => interopDefault(import('..\\pages\\pay\\orderCenter.vue' /* webpackChunkName: "pages_pay_orderCenter" */))
const _e59107b6 = () => interopDefault(import('..\\pages\\pay\\shopCar.vue' /* webpackChunkName: "pages_pay_shopCar" */))
const _3440b677 = () => interopDefault(import('..\\pages\\pay\\success1.vue' /* webpackChunkName: "pages_pay_success1" */))
const _10f398a2 = () => interopDefault(import('..\\pages\\myCenter\\notice\\_id.vue' /* webpackChunkName: "pages_myCenter_notice__id" */))
const _bf62d2c8 = () => interopDefault(import('..\\pages\\myCenter\\order\\_id.vue' /* webpackChunkName: "pages_myCenter_order__id" */))
const _6249065a = () => interopDefault(import('..\\pages\\help\\_id.vue' /* webpackChunkName: "pages_help__id" */))
const _39145f93 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/categorylist",
    component: _7ba9d42a,
    name: "categorylist"
  }, {
    path: "/goodsDetail",
    component: _0b63f4c8,
    name: "goodsDetail"
  }, {
    path: "/help",
    component: _2409cf72,
    name: "help"
  }, {
    path: "/myCenter",
    component: _41370112,
    name: "myCenter"
  }, {
    path: "/myCenter/account",
    component: _1c079a26,
    name: "myCenter-account"
  }, {
    path: "/myCenter/addressManage",
    component: _760ce339,
    name: "myCenter-addressManage"
  }, {
    path: "/myCenter/assetsManage",
    component: _17f5f1b8,
    name: "myCenter-assetsManage"
  }, {
    path: "/myCenter/collect",
    component: _2cd2436a,
    name: "myCenter-collect"
  }, {
    path: "/myCenter/notice",
    component: _5b4e208c,
    name: "myCenter-notice"
  }, {
    path: "/myCenter/order",
    component: _12275198,
    name: "myCenter-order"
  }, {
    path: "/myCenter/safe",
    component: _0db8e006,
    name: "myCenter-safe"
  }, {
    path: "/pay/orderCenter",
    component: _6802be6a,
    name: "pay-orderCenter"
  }, {
    path: "/pay/shopCar",
    component: _e59107b6,
    name: "pay-shopCar"
  }, {
    path: "/pay/success1",
    component: _3440b677,
    name: "pay-success1"
  }, {
    path: "/myCenter/notice/:id",
    component: _10f398a2,
    name: "myCenter-notice-id"
  }, {
    path: "/myCenter/order/:id",
    component: _bf62d2c8,
    name: "myCenter-order-id"
  }, {
    path: "/help/:id",
    component: _6249065a,
    name: "help-id"
  }, {
    path: "/",
    component: _39145f93,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
