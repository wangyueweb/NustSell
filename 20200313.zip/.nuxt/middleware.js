const middleware = {}

middleware['authorities'] = require('..\\middleware\\authorities.js')
middleware['authorities'] = middleware['authorities'].default || middleware['authorities']

export default middleware
